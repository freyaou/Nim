import java.util.Scanner;
import java.util.Random;
public class Nim2
{
    static Scanner in = new Scanner (System.in);
    static Random random = new Random ();
    static int rstick;
    public static void main(String[] args){
        System.out.println("Welcome to Nim!");
        System.out.println("For Single-player, press 1");
        System.out.println("For Multiplayer, press 2");
        System.out.println("To Exit, press 3");
        int selection = in.nextInt();
        while (selection != 3){
            if (selection == 1){
                singlePlayer();
            } else if (selection == 2){
                instructions();
            } else {
                System.out.println("Invalid answer! Choose 1 or 2!");
            }
            selection = in.nextInt();
        }
    }
    
    public static void singlePlayer(){
        System.out.println("For Easy mode, press 1");
        System.out.println("For Casino mode, press 2");
        System.out.println("To Escape, press 3");
        int selection = in.nextInt();
        while (selection != 3){
            if (selection == 1){
                instructionsComp();
            } else if (selection == 2){
                instructionsComp();
            } else {
                System.out.println("Invalid answer! Choose 1 or 2!");
            }
            selection = in.nextInt();
        }
    }
    
    public static void instructionsComp(){
        in.nextLine();
        System.out.print("What is your name? ");
        String name = in.nextLine();
        System.out.printf("Hello %s, you are playing against the Computer. Good luck.\n", name);
        System.out.print("How many sticks do you want to start with? ");
        int sticksInitial = in.nextInt();
        System.out.println("Players can remove one or two sticks.");
        printStick(sticksInitial);
        calcSticksCompE(sticksInitial);
    }
    
    public static void calcSticksCompE(int sticksLeft){
        while (sticksLeft > 2){
            System.out.print("Player remove how many sticks? ");
            int decrease = in.nextInt();
            sticksLeft = sticksLeft(decrease, sticksLeft);
            printStick(sticksLeft);
            rstick = random.nextInt(2) + 1;
            
            System.out.printf("Computer remove %d sticks\n", rstick);
            decrease = rstick;
            sticksLeft = sticksLeft(decrease, sticksLeft);
            printStick(sticksLeft);
        }
        
        if (sticksLeft == 2){
            System.out.print("Player remove how many sticks? ");
            int decrease = in.nextInt();
            if (decrease == 1){
                sticksLeft = sticksLeft(decrease, sticksLeft);
                printStick(sticksLeft);
                System.out.println("Player wins!");
            } else if (decrease == 2){
                System.out.println("Computer wins! You stupid, Player.");
            } 
        } else if (sticksLeft == 1){
            System.out.println("Computer wins!");
        } else if (sticksLeft == 0){
            System.out.println("Player wins!");
        }
    }
    
    public static void instructions(){
        System.out.print("How many sticks do you want to start with? ");
        int sticksInitial = in.nextInt();
        System.out.println("Players can remove one or two sticks.");
        printStick(sticksInitial);
        calcSticks(sticksInitial);
    }
    
    public static void printStick(int n){
        for (int i = 0; i < n; i++){
            System.out.print("|");
        }
        System.out.println("");
    }
    
    public static int sticksLeft(int decrease, int sticksLeft){
        sticksLeft = sticksLeft - decrease;
        return sticksLeft;
    }
    
    public static void calcSticks(int sticksLeft){
        while (sticksLeft > 2){
            System.out.print("Player 1 remove how many sticks? ");
            int decrease = in.nextInt();
            sticksLeft = sticksLeft(decrease, sticksLeft);
            printStick(sticksLeft);
          
            System.out.print("Player 2 remove how many sticks? ");
            decrease = in.nextInt();
            sticksLeft = sticksLeft(decrease, sticksLeft);
            printStick(sticksLeft);
        }
        if (sticksLeft == 2){
            System.out.print("Player 1 remove how many sticks? ");
            int decrease = in.nextInt();
            if (decrease == 1){
                sticksLeft = sticksLeft(decrease, sticksLeft);
                printStick(sticksLeft);
                System.out.println("Player 1 wins!");
            } else if (decrease == 2){
                System.out.println("Player 2 wins! You stupid, Player 1.");
            } 
        } else if (sticksLeft == 1){
            System.out.println("Player 2 wins!");
        } else if (sticksLeft == 0){
            System.out.println("Player 1 wins!");
        }
    }
}